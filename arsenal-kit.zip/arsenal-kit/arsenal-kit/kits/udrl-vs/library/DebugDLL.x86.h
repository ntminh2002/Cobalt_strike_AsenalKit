// C:\> py.exe udrl.py xxd .\beacon_x86.bin .\library\DebugDLL.x86.h
unsigned char debug_dll[] = {
	0x90 //Change Me
};
